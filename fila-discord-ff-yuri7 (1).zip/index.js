const { Client, GatewayIntentBits } = require('discord.js');
const { token, prefix } = require('./config.json');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

const fila = [];

client.on('ready', () => {
  console.log(`🤖 Bot YURI 7 logado como ${client.user.tag}`);
});

client.on('messageCreate', async message => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const comando = args.shift().toLowerCase();

  if (comando === 'entrar') {
    if (fila.includes(message.author.id)) {
      return message.reply('⚠️ Você já está na fila.');
    }

    fila.push(message.author.id);
    return message.reply(`✅ Você entrou na fila! Total na fila: ${fila.length}`);
  }

  if (comando === 'sair') {
    const index = fila.indexOf(message.author.id);
    if (index === -1) {
      return message.reply('❌ Você não está na fila.');
    }

    fila.splice(index, 1);
    return message.reply('🚪 Você saiu da fila.');
  }

  if (comando === 'fila') {
    if (fila.length === 0) return message.reply('🔁 A fila está vazia.');

    const nomes = await Promise.all(fila.map(async id => {
      const user = await client.users.fetch(id);
      return user.username;
    }));

    return message.channel.send(`🎮 Jogadores na fila:
${nomes.join('\n')}`);
  }

  if (comando === 'limpar') {
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('❌ Apenas administradores podem limpar a fila.');
    }

    fila.length = 0;
    return message.channel.send('🧹 Fila limpa com sucesso.');
  }
});

client.login(token);
